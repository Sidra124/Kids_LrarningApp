package com.example.learningapp;

public class UserModel {
    String id="";
    String animalImage="";
    String animalSound="";
    String colorImage="";
    String fruitImage="";
    String fruitSound="";


    public UserModel(String id, String animalImage, String animalSound, String colorImage, String fruitImage, String fruitSound) {
        this.id = id;
        this.animalImage=animalImage;
        this.animalSound=animalSound;
        this.colorImage=colorImage;
        this.fruitImage=fruitImage;
        this.fruitSound=fruitSound;

    }
    public UserModel(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAnimalImage() {
        return animalImage;
    }

    public void setAnimalImage(String animalImage) {
        this.animalImage = animalImage;
    }

    public String getAnimalSound() {
        return animalSound;
    }

    public void setAnimalSound(String animalSound) {
        this.animalSound = animalSound;
    }

    public String getColorImage() {
        return colorImage;
    }

    public void setColorImage(String colorImage) {
        this.colorImage = colorImage;
    }

    public String getFruitImage() {
        return fruitImage;
    }

    public void setFruitImage(String fruitImage) {
        this.fruitImage = fruitImage;
    }

    public String getFruitSound() {
        return fruitSound;
    }

    public void setFruitSound(String fruitSound) {
        this.fruitSound = fruitSound;
    }





}
