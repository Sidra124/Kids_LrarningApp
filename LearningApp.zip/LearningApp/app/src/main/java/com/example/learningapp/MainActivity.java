package com.example.learningapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    EditText username, schoolName, reSchoolName;
    Button login, signup;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username=findViewById(R.id.username);
        schoolName=findViewById(R.id.schoolName);
        reSchoolName=findViewById(R.id.reSchoolName);
         login =findViewById(R.id.login1);
         signup=findViewById(R.id.signup);
        DB=new DBHelper(this);

         signup.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String user=username.getText().toString();
                 String school=schoolName.getText().toString();
                 String reSchool=reSchoolName.getText().toString();

                 if(TextUtils.isEmpty(user) || TextUtils.isEmpty(school) || TextUtils.isEmpty(reSchool))
                     Toast.makeText(MainActivity.this, "All fields Required", Toast.LENGTH_SHORT).show();

                 else{
                     if(school.equals(reSchool)){
                         Boolean checkUser =DB.checkUsername(user);
                         if(checkUser==false){
                             Boolean insert= DB.insertData(user,school);
                             if(insert==true){
                                 Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                 Intent intent=new Intent(getApplicationContext(), HomeActivity.class);
                                 startActivity(intent);
                                 finish();
                             }else{
                                 Toast.makeText(MainActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                             }

                         }else{
                             Toast.makeText(MainActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                         }
                     }else{
                         Toast.makeText(MainActivity.this, "Passwords are not matching", Toast.LENGTH_SHORT).show();
                     }

                 }


             }
         });




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}